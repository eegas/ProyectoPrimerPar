package proyectoprimerparcial;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Edison
 */
public class Usuario {
    private String usuario;
    private ArrayList<Boolean> favoritos;
    private ArrayList<String> dispositivosFav;

    public Usuario(String usuario) {
        this.usuario = usuario;
    }

    public Usuario(String usuario, ArrayList<Boolean> favoritos, ArrayList<String> dispositivosFav) {
        this.usuario = usuario;
        this.favoritos = favoritos;
        this.dispositivosFav = dispositivosFav;
    }
    

  
    public void llenarListaDispo() throws IOException{
            Scanner sc = new Scanner(System.in);
           leerDatos leerDoc= new leerDatos(",","");
          ArrayList<String>datodis =new ArrayList<String>();
          datodis=leerDoc.cargarDatoCSVSimple("iot_telemetry_data_new.csv",1);
          ArrayList<String>unicos =new ArrayList<String>();
          for (String w :datodis){
              if(!unicos.contains(w)){
                  unicos.add(w);
              }
          }
          ArrayList<String>entrega =new ArrayList<String>();
          System.out.println("Desea tener los datos que emiten todos los dispositivos");
          System.out.println("Responda si/no");
          String datos = sc.nextLine();
          if(datos.equals("si")){
              this.dispositivosFav=unicos;
          }else{
              System.out.println("Seliccione con si/no los dispositvos de preferencia");
          for (String h : unicos){
              System.out.println("dispositivo"+h);
             String pre = sc.nextLine(); 
              if(pre.equals("si")){
                  entrega.add(h.trim());
              }else{
                  entrega.add(null);
              }
              
          }
          this.dispositivosFav=entrega;
          }
    }

    public String getUsuario() {
        return usuario;
    }

    public ArrayList<Boolean> getFavoritos() {
        return favoritos;
    }

    public ArrayList<String> getDispositivos() {
        return dispositivosFav;
    }
     public void llenarListaFavoritos() throws IOException{
           Scanner sc = new Scanner(System.in);
           ArrayList<String>datodis;
            datodis = new ArrayList<>();
            datodis.add("co");
            datodis.add("humidity");
            datodis.add("light");
            datodis.add("lpg");
            datodis.add("motion");
            datodis.add("smoke");
            datodis.add("temp");
             ArrayList<Boolean>booll;
            booll = new ArrayList<>();
            booll.add(true);
            booll.add(true);
            booll.add(true);
            booll.add(true);
            booll.add(true);
            booll.add(true);
            booll.add(true);     
          System.out.println("Desea tener los datos que emiten todos los sensores");
          System.out.println("Responda si/no");
          String datos = sc.nextLine();
          if(datos.equals("si")){
              this.favoritos= booll;
          }else{
              System.out.println("Seliccione con si/no los dispositvos de preferencia");
              booll.clear();
          for (String h : datodis){
              System.out.println("sensor: "+h);
             String pre = sc.nextLine(); 
              if(pre.equals("si")){
                  booll.add(true);
              }else{
                  booll.add(false);
              }
              
          }
          this.favoritos= booll;
          }
    }
    //Corregir para que funcione registras
    public String datosEntrega(){
        String us =getUsuario();
        ArrayList<Boolean>booll;
        booll = this.favoritos;
         ArrayList<String>dd;
        dd = this.dispositivosFav;
         ArrayList<String>entregar;
        entregar = new ArrayList<>();
        entregar.add(us);
        for(Boolean a :booll){
            if(a){entregar.add("si");}
            else{entregar.add("no");}
        }
         for(String t :dd){
            
            entregar.add(t);
        }
         return entregar.toString().substring(1,entregar.toString().length()-1 );
        
    }
        
    
    //ususuario,v,t,t,diso4,diso5,diso5  
}
