
package proyectoprimerparcial;

import java.io.IOException;
import java.util.Date;
import java.text.SimpleDateFormat;

/**
 *
 * @author Edison
 */
public class Main {
    //Retorna la fecha actual 
    static public String fecha(){
        Date objDate = new Date();
     System.out.println(objDate);
        String strDateFormat = "dd/MM/yyyy hh:mm"; // El formato de fecha está especificado  
        SimpleDateFormat objSDF = new SimpleDateFormat(strDateFormat); // La cadena de formato de fecha se pasa como un argumento al objeto 
        System.out.println(objSDF.format(objDate));
        return objSDF.format(objDate);   
    }
    
          
 
    public static void main(String[] args) throws IOException {
         leerDatos al= new leerDatos(",",""); 
        String ruta="C:\\Users\\Edison\\Documents\\NetBeansProjects\\ProtyectoPrimerPar\\src\\proyectoprimerparcial";
        System.out.println(al.cargarDatoCSVSimple(ruta,9));
    }
    
       
      
    }
    
