
package proyectoprimerparcial;
import java.io.IOException;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.io.*;
import static java.lang.System.exit;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


/**
 *
 * @author Edison
 */
public class Main {
    //Retorna la fecha actual 
 
    public static Usuario unicoUs;
    public static Scanner sc = new Scanner(System.in);
    public static  String fecha(){
        Date objDate = new Date();
        //System.out.println(objDate);
        String strDateFormat = "dd/MM/yyyy hh:mm"; // El formato de fecha está especificado  
        SimpleDateFormat objSDF = new SimpleDateFormat(strDateFormat); // La cadena de formato de fecha se pasa como un argumento al objeto 
        //System.out.println(objSDF.format(objDate));
        return objSDF.format(objDate);   
    }
    public static  void registrarUsuario() throws IOException{
        
          File archivo;
          FileReader r;
          BufferedReader br;
         System.out.println("Por favor ingrese su ususario nuevo");
                String nombre = sc.next();
                try{
                archivo = new File("DatosUsuario.txt");
                r = new FileReader(archivo);
                br = new BufferedReader(r);
                String linea;
                while((linea=br.readLine())!=null){
                    Pattern patron = Pattern.compile(nombre,1);
                    Matcher matcher = patron.matcher(linea);
                    if(matcher.find()){    
                        System.out.println("El usuario ya existe");
                        break;
                    }
                    else {}
                }
            } catch(Exception e){
                System.out.println("Intente de nuevo");
            }
            unicoUs=new Usuario(nombre);
            unicoUs.llenarListaDispo();
            unicoUs.llenarListaFavoritos();
            System.out.println(unicoUs.datosEntrega());
         
            FileWriter w;
            
            BufferedWriter bw;
            
            PrintWriter wr;
             try{
            
            archivo = new File("DatosUsuario.txt");
            w = new FileWriter(archivo, true);
            r = new FileReader(archivo);
            bw= new BufferedWriter(w);
            br = new BufferedReader(r);
            wr = new PrintWriter(bw);
            
            
            
            //wr.write("Usuarios");
            wr.append("\n"+unicoUs.datosEntrega());
            
            wr.close();
            bw.close();
                 System.out.println("Regsitro Exitoso");
            
        } catch(Exception e){
            
        }
             
                
                
    }
     public static void menu() throws IOException{
    String opcion="";  
    while(!opcion.equals("3")){
    System.out.println("Bienvenido");
    System.out.println("1.Registrar Usuario");
    System.out.println("2.iniciar sesion");
    System.out.println("3.salir");
   
    
    System.out.print("Opcion:");
    opcion = sc.nextLine();
    switch(opcion){
      case "1":
        registrarUsuario();
        break;
      case "2":
        iniciarSesion();
        break;
    }
    }
  }
    public static  void iniciarSesion() throws IOException{
    System.out.println("Ingrese su usuario existente");
    String nombre = sc.next();
           File archivo;
          FileReader r;
          BufferedReader br;
     try{
            

                archivo = new File("DatosUsuario.txt");
                r = new FileReader(archivo);
                br = new BufferedReader(r);

                String linea;
                ArrayList<String> datosUs=new ArrayList<>();
                while((linea=br.readLine())!=null){
                    
                    String[] elementos = linea.split(",");
                    String usuario = elementos[0];
                    datosUs.add(usuario);
                    
    
                    }
                r.close();
                br.close();
                boolean bandera =true;
                while(bandera){
                if(datosUs.contains(nombre)){
                    System.out.println("Inicio de sesion Exitoso");
                    bandera =false;
                   }else{
                    System.out.println("El ususario no existe");
                    System.out.println("Intente denuevo");
                    nombre = sc.next();
                    
                }}
                
                    
            } catch(Exception e){
                System.out.println("Intente de nuevo");

            }
     ArrayList<String> daBool=new ArrayList<>();
           
     try{
            

                archivo = new File("DatosUsuario.txt");
                r = new FileReader(archivo);
                br = new BufferedReader(r);

                String linea;
                
                
                while((linea=br.readLine())!=null){
                    
                    
                    String[] elementos = linea.split(",");
                    String usuario = elementos[0];
                    if(usuario.equals(nombre)){
                        for (int i = 1; i <= 7; ++i){
                            String ele =elementos[i];
                            daBool.add(ele);
                    }
                        dispos.add(elementos[8].trim());
                        dispos.add(elementos[9].trim());
                        dispos.add(elementos[10].trim()); 
                    
                    }}

                
                
                r.close();
                br.close();    
            } catch(Exception e){
                System.out.println("Intente de nuevo");
                

            }
   
                          for (String d :daBool){
                         
                          String w =d.trim();
                         if (w.equals("si")){
                           activas.add(true);
                            }else{
                           activas.add(false);
                                }
                }
            
            unicoUs=new Usuario(nombre, activas , dispos);       
           Paquete.add(co(unicoUs));
           Paquete.add(humidity(unicoUs));
           Paquete.add(light(unicoUs));
           Paquete.add(lpg(unicoUs));
           Paquete.add(motion(unicoUs));
           Paquete.add(smoke(unicoUs));
           Paquete.add(temp(unicoUs));
           
        int tama=activas.size();
         
         for (int i = 0; i < tama; ++i){
             if(activas.get(i)){
                 Paquete.get(i).notficacionActual(fecha().trim());
             }
                }
         
           
     
        
        
    String opcion="";  
    while(!opcion.equals("5")){
    System.out.println("Bienvenido: "+nombre);
    System.out.println("Fecha de hoy: "+fecha());
    System.out.println("1.-Buscar Datos de un dia ");
    System.out.println("2.-Buscar datos entre rangos de dias");
    System.out.println("3.-Cambiar preferencias de disposvo");
    System.out.println("4.-Cambiar preferecais de sensores");  
    System.out.println("5.-Salir");
    int datoInt=Paquete.size();
    
    System.out.println("Opcion:");
    opcion = sc.nextLine();
    switch(opcion){
      case "1":
          System.out.println("ingrese se la fecha:dd/mm/yyyy");
        String fechaActual = sc.next();
      
        int tamaño=activas.size();
         for (int i = 0; i < tamaño; ++i){
             if(activas.get(i)){
                 Paquete.get(i).notficacionActual(fechaActual);
             }
             }
          

        break;
      case "2":
            System.out.println("ingrese se la fecha:dd/mm/yyyy");
            System.out.println("Fecha inicial");
        String fecha1 = sc.next();
        System.out.println("Fecha final");
        String fecha2 = sc.next();
      
        int ta=activas.size();
         for (int i = 0; i < ta; ++i){
             if(activas.get(i)){
                 Paquete.get(i).notficacionRango(fecha1, fecha2);
             }
             }
          
        //retirar();
        break;
      case "3":
          unicoUs.llenarListaDispo();
        //consultarSaldos();
        break;
      case "4":
          unicoUs.llenarListaFavoritos();
        //consultarMillas();
        break;
  
    }}}
    //bloque de arrays**************************************************************************
    public static  ArrayList<Boolean> activas = new ArrayList<>();
    public static  ArrayList<Notificaciones> Paquete= new ArrayList<>();
    public static  ArrayList<String> dispos=new ArrayList<>();
    //bloque de sensores************************************************************************
    public static NotificacionesNum  co(Usuario s) throws IOException{
        leerDatos leerDoc= new leerDatos(",","");
         //bloque de co falta llenar datos 
         ArrayList<String>datoCo =new ArrayList<String>();
         datoCo=leerDoc.cargarDatoCSVSimple("iot_telemetry_data_new.csv",2);
         Sensor co = new Sensor("co",datoCo,"double");
         NotificacionesNum notiCO=new NotificacionesNum(0.004,  0.005,  0.002, "Estado estable","peligo", "debajo del promedio",co, s.getDispositivos(),"co en el ambiente");
         return notiCO;
    }
     public static NotificacionesNum  humidity(Usuario s) throws IOException{
        leerDatos leerDoc= new leerDatos(",","");
         //bloque de co falta llenar datos 
         ArrayList<String>datoCo =new ArrayList<String>();
         ArrayList<String>datohumidity =new ArrayList<String>();
         datohumidity=leerDoc.cargarDatoCSVSimple("iot_telemetry_data_new.csv",3);
         Sensor humidity = new Sensor("humidity",datohumidity,"double");
         NotificacionesNum notihumidity=new NotificacionesNum(60,  70,  40, "Estado estable","peligo", "debajo del promedio",humidity, s.getDispositivos(),"humedad en el ambiente");
         return notihumidity;
    }
      public static NotificacionesNum  lpg(Usuario s) throws IOException{
        leerDatos leerDoc= new leerDatos(",","");
         //bloque de co falta llenar datos 
        ArrayList<String>datolpg =new ArrayList<String>();
         datolpg=leerDoc.cargarDatoCSVSimple("iot_telemetry_data_new.csv",5);
         Sensor lpg = new Sensor("humidity",datolpg,"double");
         NotificacionesNum notilpg=new NotificacionesNum(0.006, 0.007,  0.004, "Estado estable","peligo", "debajo del promedio",lpg, s.getDispositivos(),"ipl en el ambiente");
        return notilpg;
    }
    public static NotificacionesNum  smoke(Usuario s) throws IOException{
        leerDatos leerDoc= new leerDatos(",","");
         //bloque de co falta llenar datos 
        ArrayList<String>datosmoke =new ArrayList<String>();
         datosmoke=leerDoc.cargarDatoCSVSimple("iot_telemetry_data_new.csv",7);
         Sensor smoke = new Sensor("humidity",datosmoke,"double");
         NotificacionesNum notismoke=new NotificacionesNum(0.0015, 0.002,  0.0005, "Estado estable","peligo", "debajo del promedio",smoke, s.getDispositivos(),"humo en el ambiente");
         return notismoke;
    }
    public static NotificacionesNum  temp(Usuario s) throws IOException{
        leerDatos leerDoc= new leerDatos(",","");
         //bloque de co falta llenar datos 
        ArrayList<String>datotemp =new ArrayList<String>();
         datotemp=leerDoc.cargarDatoCSVSimple("iot_telemetry_data_new.csv",8);
         Sensor temp = new Sensor("humidity",datotemp,"double");
        NotificacionesNum notitemp=new NotificacionesNum(27, 38, 20, "Estado estable","peligo", "debajo del promedio",temp,s.getDispositivos(),"humo en el ambiente");
        return notitemp;
    }
    public static NotificacionesBoolean  light(Usuario s) throws IOException{
        leerDatos leerDoc= new leerDatos(",","");
         //bloque de co falta llenar datos 
       ArrayList<String>datolight =new ArrayList<String>();
         datolight=leerDoc.cargarDatoCSVSimple("iot_telemetry_data_new.csv",4);
         Sensor light= new Sensor("light",datolight,"boolean");
         NotificacionesBoolean notlight=new NotificacionesBoolean("Esendido","Apagado",light,s.getDispositivos());
         return notlight;
    }
    public static NotificacionesBoolean  motion(Usuario s) throws IOException{
        leerDatos leerDoc= new leerDatos(",","");
         //bloque de co falta llenar datos 
      ArrayList<String>datomotion =new ArrayList<String>();
         datomotion=leerDoc.cargarDatoCSVSimple("iot_telemetry_data_new.csv",6);
         Sensor motion= new Sensor("light",datomotion,"boolean");
         NotificacionesBoolean notmotion=new NotificacionesBoolean("movimiento","detenido",motion,s.getDispositivos());
         return notmotion;
    }
    
    public static void main(String[] args) throws IOException {
        menu();
        
          
        
        
         
          
        
         
        
    }
    
       
      
    }
    
