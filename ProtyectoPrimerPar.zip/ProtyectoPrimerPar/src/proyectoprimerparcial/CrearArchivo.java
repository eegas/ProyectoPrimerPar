/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectoprimerparcial;
import java.io.PrintWriter;
import java.util.ArrayList;
/**
 *
 * @author Edison
 */

public class CrearArchivo {
    public String ruta ;
    public String nombreText ;
    public CrearArchivo(String ruta, ArrayList<String> datos, String nombreText) {
        this.ruta = ruta;     
        this.nombreText = nombreText;
    }

    CrearArchivo(String cUsersEdisonDocumentsNetBeansProjectsProy, String nombre) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public void escribirBorrables(ArrayList<String> datos){
        try {
            PrintWriter writer = new PrintWriter("/"+ruta+"/"+nombreText+".txt", "UTF-8");
            for(String s : datos ){
            writer.println(s);
           }
            writer.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void llenarDatos(ArrayList<String> us){
          try {
            PrintWriter writer = new PrintWriter("/"+ruta+"/"+nombreText+".txt", "UTF-8");
            for(String s : us ){
            writer.write(s);
           }
            writer.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        
    }
}

