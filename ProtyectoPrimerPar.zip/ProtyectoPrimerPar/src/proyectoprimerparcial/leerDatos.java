
package proyectoprimerparcial;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;



/**
 *Esta clase lee los datos csv y con el metodo cargar datos retorna
 * un Arralist de tipo de String con los datos de acuerdo al indice 
 * que se solicite
 */
public class leerDatos {
    private String separador;
    private String comillas;
    
	
	// Constructor
	
	/**
	 * Inicializa el constructor definiendo el separador de los campos y las comillas usadas
	 * @param separador
	 * @param comillas
	 */
	public leerDatos(String separador, String comillas) {
		this.separador = separador;
		this.comillas = comillas;
	}
	
	// Métodos
	/**
	 * Lee un CSV que no contiene el mismo caracter que el separador en su texto
	 * y sin comillas que delimiten los campos
	 
	 * @throws IOException 
	 */
	public  ArrayList<String> cargarDatoCSVSimple(String path,int num) throws IOException {
            
		// Abro el .csv en buffer de lectura
		BufferedReader bufferLectura = new BufferedReader(new FileReader(path));
		
		// Leo una línea del archivo
		String linea = bufferLectura.readLine();
                
		ArrayList<String> result = new ArrayList<String>();
                linea = bufferLectura.readLine();
                
		while (linea != null) {
			// Separa la línea leída con el separador definido previamente
			String[] campos = linea.split(String.valueOf(this.separador));
                        
			//System.out.println(campos[4]);
                        result.add(campos[num]);
			// Vuelvo a leer del fichero
			linea = bufferLectura.readLine();
		}
		
		// CIerro el buffer de lectura

			bufferLectura.close();
                        return result;
		}
	}
	

	

    
    

