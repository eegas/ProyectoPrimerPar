/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectoprimerparcial;
import java.io.IOException;
import java.util.ArrayList;


/**
 *
 * @author Edison
 */
public abstract class Notificaciones {
    protected ArrayList<String> fechas ;
    protected ArrayList<String> dispositivos ;
    protected Sensor send ;
    protected ArrayList<String> dispositivosFavoritos ;
   protected boolean notificacionEstado;
    public Notificaciones(Sensor send,ArrayList<String> dispositivosFavoritos,boolean notificacionEstado) throws IOException {
         super();
        ArrayList<String> fechas = new ArrayList<String>();
        leerDatos al= new leerDatos(",",""); 
        String ruta="C:\\Users\\Edison\\Documents\\NetBeansProjects\\ProyectoPrimerParcial\\src\\proyectoprimerparcial\\iot_telemetry_data_new.csv";
        fechas=al.cargarDatoCSVSimple(ruta,9);
        this.fechas = fechas;
        ArrayList<String> dispositivos  = new ArrayList<String>();
        dispositivos =al.cargarDatoCSVSimple(ruta,1);
        this.dispositivos  = dispositivos ;
        this.send = send;
        this.dispositivosFavoritos=dispositivosFavoritos;
        this.notificacionEstado=true;
    }
    public Notificaciones(Sensor send,ArrayList<String> dispositivosFavoritos) throws IOException {
        ArrayList<String> fechas = new ArrayList<String>();
        leerDatos al= new leerDatos(",",""); 
        String ruta="C:\\Users\\Edison\\Documents\\NetBeansProjects\\ProyectoPrimerParcial\\src\\proyectoprimerparcial\\iot_telemetry_data_new.csv";
        fechas=al.cargarDatoCSVSimple(ruta,9);
        this.fechas = fechas;
        ArrayList<String> dispositivos  = new ArrayList<String>();
        dispositivos =al.cargarDatoCSVSimple(ruta,1);
        this.dispositivos  = dispositivos ;
        this.send = send;
        this.dispositivosFavoritos=dispositivosFavoritos;
        this.notificacionEstado=true;
    }
    abstract void notficacionActual(String fechaActual,ArrayList<String> dispositivosFavoritos);
    abstract void notficacionRango(String fechaIncial,String fechaFinal,ArrayList<String> dispositivosFavoritos);
    //abstract void notificacionPorDia(String fechaUnica,ArrayList<String> dispositivosFavoritos);
    public void cambioEstado(){
        this.notificacionEstado = this.notificacionEstado != true;
    }
    public boolean getEstado(){
    return this.notificacionEstado;}
    
    
    
        
    
    

        
            
    
}
