/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectoprimerparcial;
import java.io.IOException;
import java.util.ArrayList;


/**
 *
 * @author Edison
 */
public abstract class NotificacionesNum extends Notificaciones {
        private double valorPromedio;
        private double valorElevado;
        private double valorBajo;
        private String menasajePromedio;
        private String menasajeElevado;
        private String menasajeBajo;
        private String medida;

    public NotificacionesNum(double valorPromedio, double valorElevado, double valorBajo, String menasajePromedio, String menasajeElevado, String menasajeBajo, Sensor send, ArrayList<String> dispositivosFavoritos, boolean notificacionEstado,String medida) throws IOException {
        super(send, dispositivosFavoritos, notificacionEstado);
        this.valorPromedio = valorPromedio;
        this.valorElevado = valorElevado;
        this.valorBajo = valorBajo;
        this.menasajePromedio = menasajePromedio;
        this.menasajeElevado = menasajeElevado;
        this.menasajeBajo = menasajeBajo;
        this.medida=medida;
    }
        @Override
    public void cambioEstado(){
    super.cambioEstado();
    }
        @Override
    public boolean getEstado(){
    return super.getEstado();}
        @Override
    public void notficacionActual(String fechaActual,ArrayList<String> dispositivosFavoritos){
        
            ArrayList<String> fechas1 = this.fechas;
            ArrayList<String> dispositivos1 = this.dispositivos;
            
            ArrayList<Integer> fechasSolicitada = new ArrayList<Integer>();//areglo de indices con la fecha que se solicita 
            int valor = fechas1.size();
            for (int i = 0; i <= valor; ++i){
                String dia = fechas1.get(i).substring(0, 9);
                if(dia.equals(fechaActual)){
                    fechasSolicitada.add(i);
                }   
            }
             ArrayList<Integer> indicesEntre = new ArrayList<Integer>();
            for (int e :fechasSolicitada){
                String dis=dispositivos1.get(e);
                if(dispositivosFavoritos.contains(dis)){
                   indicesEntre.add(e);
                }  
            }
            ArrayList<Double> datos = send.getDatosDouble();
            ArrayList<Double> valorFinal= new ArrayList<Double>();
            for (int o :indicesEntre){
                double f =datos.get(o);
                 valorFinal.add(f);
            }
            System.out.println("Para la fecha del:"+fechaActual);
            for (double w :valorFinal){
                if (w>=this.valorElevado){
                    System.out.println(this.menasajeElevado+":");
                    System.out.print(w);
                    System.out.println("en "+this.medida);   
                } else if(w<this.valorElevado && w>=this.valorPromedio){
                    System.out.println(this.menasajePromedio+":");
                    System.out.print(w);
                    System.out.println("en "+this.medida);  
                }else{
                    System.out.println(this.menasajeBajo+":");
                    System.out.print(w);
                    System.out.println("en "+this.medida);  
                    
                }
            }  
    }
        @Override
    public void notficacionRango(String fechaIncial,String fechaFinal,ArrayList<String> dispositivosFavoritos){
    }
    
  
        

    
  


    
}
