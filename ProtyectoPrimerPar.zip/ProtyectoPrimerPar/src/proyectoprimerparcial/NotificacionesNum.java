/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectoprimerparcial;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;

import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author Edison
 */
public  class NotificacionesNum extends Notificaciones {
        private double valorPromedio;
        private double valorElevado;
        private double valorBajo;
        private String menasajePromedio;
        private String menasajeElevado;
        private String menasajeBajo;
        private String medida;

    public NotificacionesNum(double valorPromedio, double valorElevado, double valorBajo, String menasajePromedio, String menasajeElevado, String menasajeBajo, Sensor send, ArrayList<String> dispositivosFavoritos,String medida) throws IOException {
        super(send, dispositivosFavoritos);
        this.valorPromedio = valorPromedio;
        this.valorElevado = valorElevado;
        this.valorBajo = valorBajo;
        this.menasajePromedio = menasajePromedio;
        this.menasajeElevado = menasajeElevado;
        this.menasajeBajo = menasajeBajo;
        this.medida=medida;
    }
        @Override
    public void cambioEstado(){
    super.cambioEstado();
    }

 
        @Override
    public boolean getEstado(){
    return super.getEstado();}
        @Override
//validar si no exite 
    public void notficacionActual(String fechaActual){
        
            ArrayList<String> fechas1 = this.fechas;
            ArrayList<String> dispositivos1 = this.dispositivos;
            
            ArrayList<Integer> fechasSolicitada = new ArrayList<Integer>();//areglo de indices con la fecha que se solicita 
            int valor = fechas1.size();
            
            
            for (int i = 0; i < valor; ++i){
                String dia = fechas1.get(i).split(" ")[0].trim();
                if(dia.equals(fechaActual.trim())){
                    fechasSolicitada.add(i);
                }   
            }
           
            
             ArrayList<Integer> indicesEntre = new ArrayList<Integer>();
            for (int e :fechasSolicitada){
                String dis=dispositivos1.get(e).trim();
                if(this.dispositivosFavoritos.contains(dis)){
                   indicesEntre.add(e);
                }  
            }
            
            
            ArrayList<Double> datos = send.getDatosDouble();
            ArrayList<Double> valorFinal= new ArrayList<Double>();
            for (int o :indicesEntre){
                double f =datos.get(o);
                 valorFinal.add(f);
            }
            
            for (double w :valorFinal){
                if (w>=this.valorElevado){
                    System.out.println(this.menasajeElevado+":");
                    System.out.print(w);
                    System.out.println("en "+this.medida);   
                } else if(w<this.valorElevado && w>=this.valorPromedio){
                    System.out.println(this.menasajePromedio+":");
                    System.out.print(w);
                    System.out.println("en "+this.medida);  
                }else{
                    System.out.println(this.menasajeBajo+":");
                    System.out.print(w);
                    System.out.println("en "+this.medida);  
                    
                }
            }  
    }
        @Override
    public void notficacionRango(String fechaIncial,String fechaFinal){
        // tranforma la fecha inicial la int
         String[] fechaIn =fechaIncial.split("/");
         
        int dia1 = Integer.valueOf(fechaIn[0].trim());
        int mes1 = Integer.valueOf(fechaIn[1].trim());
        int año1 = Integer.valueOf(fechaIn[2].trim());
        String[] fechaFi =fechaFinal.split("/");
        int dia2 = Integer.valueOf(fechaFi[0].trim());
        int mes2 = Integer.valueOf(fechaFi[1].trim());
        int año2 = Integer.valueOf(fechaFi[2].trim());
        ArrayList<Integer> indices = new ArrayList<Integer>();//indices
        ArrayList<String> fechas1 = this.fechas;
        //ArrayList<String> dispositivos1 = this.dispositivos;
        //se itera los faltante
        //21/01/2020%21/08/2020
        //(22/01/2020,23/01/2020)
        int val=fechas1.size();
        for (int i = 0; i < val; ++i){
               
            
                String[]fecha=fechas1.get(i).split(" ");
                String fech= fecha[0];
                String[] fechAnal=fech.split("/");
               
               
                int dia3 = Integer.valueOf(fechAnal[0].trim());
                int mes3 = Integer.valueOf(fechAnal[1].trim());
                int año3 = Integer.valueOf(fechAnal[2].trim());
              
                if(año3>=año1 && año3<=año2){
                    
                    if(mes3>=mes1 && mes3<=mes2){
                        
                        if(dia3>=dia1 && dia3<=dia2){
                            
                            indices.add(i);
                                } }} }
        ArrayList<String> fechasFill= new ArrayList<>();
        for (int a :indices){
            String dat =fechas1.get(a);
            fechasFill.add(dat);
        }
        //855555555555555555555555555555555555555555
            //System.out.println(fechasFill.toString());
        for (String u :fechasFill){
            notficacionActual(u);
        }
          
        
        
        
    }

    public void setValorPromedio(double valorPromedio) {
        this.valorPromedio = valorPromedio;
    }

    public void setValorElevado(double valorElevado) {
        this.valorElevado = valorElevado;
    }

    public void setValorBajo(double valorBajo) {
        this.valorBajo = valorBajo;
    }

    public void setMenasajePromedio(String menasajePromedio) {
        this.menasajePromedio = menasajePromedio;
    }

    public void setMenasajeElevado(String menasajeElevado) {
        this.menasajeElevado = menasajeElevado;
    }

    public void setMenasajeBajo(String menasajeBajo) {
        this.menasajeBajo = menasajeBajo;
    }

    public void setMedida(String medida) {
        this.medida = medida;
    }
     public void trabajoINter(String fechaActual) throws FileNotFoundException, UnsupportedEncodingException {
         
        
          ArrayList<String> fechas1 = this.fechas;
            ArrayList<String> dispositivos1 = this.dispositivos;
            
            ArrayList<Integer> fechasSolicitada = new ArrayList<Integer>();//areglo de indices con la fecha que se solicita 
            int valor = fechas1.size();
            
            
            for (int i = 0; i < valor; ++i){
                String dia = fechas1.get(i).split(" ")[0].trim();
                if(dia.equals(fechaActual.trim())){
                    fechasSolicitada.add(i);
                }   
            }
            
            
             ArrayList<Integer> indicesEntre = new ArrayList<Integer>();
            for (int e :fechasSolicitada){
                String dis=dispositivos1.get(e).trim();
                if(this.dispositivosFavoritos.contains(dis)){
                   indicesEntre.add(e);
                }  
            }
            
            
            ArrayList<Double> datos = send.getDatosDouble();
            ArrayList<Double> valorFinal= new ArrayList<Double>();
            for (int o :indicesEntre){
                double f =datos.get(o);
                 valorFinal.add(f);
            }
            //imprim archivo
            PrintWriter writer = new PrintWriter(send.getNombre()+".txt", "UTF-8");
            writer.append("Para la fecha del:"+fechaActual);
            if(valorFinal.size()>0){
            for (double w :valorFinal){
                if (w>=this.valorElevado){
                    writer.append("\n"+this.menasajeElevado+":");
                    writer.append((char) (int) w);
                    writer.append("en "+this.medida);   
                } else if(w<this.valorElevado && w>=this.valorPromedio){
                 writer.append("\n"+this.menasajePromedio+":");
                    writer.append((char) (int) w);
                    writer.append("en "+this.medida+"\t");  
                }else{
                    writer.append("\n"+this.menasajeBajo+":");
                    writer.append((char) (int) w);
                    writer.append("en "+this.medida+"\t");  
                    
                    
                }
               
            }
            
            writer.close();
            
            }else{writer.println("No existen datos");}
            
    }

}
     
        
       

    
  


    
