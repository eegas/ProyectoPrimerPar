/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectoprimerparcial;

import java.util.ArrayList;

/**
 * La clase sensor va ayatudar sacar los datos necesarios 
 * para poder trabajar con Notificaciones 
 * @author Edison
 */
public class Sensor {
    private String nombre;
    private ArrayList<String> datos ;
    private String tipoDato;

    public Sensor(String nombre, ArrayList<String> datos, String tipoDato) {
        this.nombre = nombre;
        this.datos = datos;
        this.tipoDato = tipoDato;
    }

    /**Estos metodos retornan las Arraylist para poder trabajar
     * deacuerdo a su Type
     * @return 
     */
    public ArrayList<Double> getDatosDouble() {
        if ("double".equals(this.tipoDato)){
            ArrayList<Double>trabajo=new ArrayList<>();
            for(String dat:this.datos){
                double valor = Double.parseDouble(dat);
                trabajo.add(valor);   
            }
            return trabajo;
        }else{
         return null;
        }
    }
    public ArrayList<Boolean> getDatosBoolean() {
        if ("double".equals(this.tipoDato)){
            ArrayList<Boolean>trabajo=new ArrayList<>();
            for(String dat:this.datos){
               if ("true".equals(dat)){
                trabajo.add(true);
               }else{
                trabajo.add(false);
               }
            }
            return trabajo;
        }else{
         return null;
        }
    }

    public String getNombre() {
        return nombre;
    }
    
    
   
}
