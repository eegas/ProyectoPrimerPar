/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectoprimerparcial;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Edison
 */
public  class NotificacionesBoolean extends Notificaciones  {
        private String mensaje1;//El mensaje si es true 
        private String mensaje2;//El mensaje si es false 
        

    public NotificacionesBoolean(String mensaje1, String mensaje2, Sensor send, ArrayList<String> dispositivosFavoritos) throws IOException {
        super(send, dispositivosFavoritos);
        this.mensaje1 = mensaje1;
        this.mensaje2 = mensaje2;  
    }

    @Override
    //completar codigo 
    void notficacionActual(String fechaActual) {
        ArrayList<String> fechas1 = this.fechas;
            ArrayList<String> dispositivos1 = this.dispositivos;
            
            ArrayList<Integer> fechasSolicitada = new ArrayList<Integer>();//areglo de indices con la fecha que se solicita 
            int valor = fechas1.size();
            for (int i = 0; i < valor; ++i){
               
               String dia = fechas1.get(i).split(" ")[0].trim();
                if(dia.equals(fechaActual.trim())){
                    fechasSolicitada.add(i);
                }   
            }
             ArrayList<Integer> indicesEntre = new ArrayList<Integer>();
            for (int e :fechasSolicitada){
                String dis=dispositivos1.get(e);
                if(this.dispositivosFavoritos.contains(dis.trim())){
                   indicesEntre.add(e);
                }  
            }
            ArrayList<Boolean> datos = send.getDatosBoolean();
            ArrayList<Boolean> valorFinal= new ArrayList<Boolean>();
            for (int o :indicesEntre){
                
                boolean f =datos.get(o);
                
                 valorFinal.add(f);
            }
            
            
            for (boolean w :valorFinal){
                if(w){
                    System.out.println(mensaje1);
                }else{
                     System.out.println(mensaje2);
                }
            }
    }
    
    @Override
    void notficacionRango(String fechaIncial, String fechaFinal) {
         // tranforma la fecha inicial la int
        String[] fechaIn =fechaIncial.split("/");
        int dia1 = Integer.parseInt(fechaIn[0].trim());
        int mes1 = Integer.parseInt(fechaIn[1].trim());
        int año1 = Integer.parseInt(fechaIn[2].trim());
        String[] fechaFi =fechaFinal.split("/");
        int dia2 = Integer.parseInt(fechaFi[0].trim());
        int mes2 = Integer.parseInt(fechaFi[1].trim());
        int año2 = Integer.parseInt(fechaFi[2].trim());
        ArrayList<Integer> indices = new ArrayList<Integer>();//indices
        ArrayList<String> fechas1 = this.fechas;
        
        //se itera los faltante
        //21/01/2020%21/08/2020
        //(22/01/2020,23/01/2020)
        int val=fechas1.size();
        for (int i = 0; i < val; ++i){
                String[]fecha=fechas1.get(i).split(" ");
                String fech= fecha[0];
                String[]fechAnal=fech.split("/");
                int dia3 = Integer.parseInt(fechAnal[0].trim());
                int mes3 = Integer.parseInt(fechAnal[1].trim());
                int año3 = Integer.parseInt(fechAnal[2].trim());
                if(año3>=año1 && año3<=año2){
                    if(mes3>=mes1 && mes3<=mes2){
                        if(dia3>=dia1 && dia3<=dia2){
                            indices.add(i);
                                } }} }
        ArrayList<String> fechasFill= new ArrayList<>();
        for (int a :indices){
            String dat =fechas1.get(a);
            fechasFill.add(dat);
        }
        for (String u :fechasFill){
           notficacionActual(u);
        }
    }
        @Override
        public void cambioEstado(){
    super.cambioEstado();
    }
        @Override
    public boolean getEstado(){
    return super.getEstado();}

    public void setMensaje1(String mensaje1) {
        this.mensaje1 = mensaje1;
    }

    public void setMensaje2(String mensaje2) {
        this.mensaje2 = mensaje2;
    }
    public void trabajoInt(String fechaActual) throws FileNotFoundException, UnsupportedEncodingException {
         
         ArrayList<String> fechas1 = this.fechas;
            ArrayList<String> dispositivos1 = this.dispositivos;
            
            ArrayList<Integer> fechasSolicitada = new ArrayList<Integer>();//areglo de indices con la fecha que se solicita 
            int valor = fechas1.size();
            for (int i = 0; i < valor; ++i){
               String dia = fechas1.get(i).split(" ")[0].trim();
                if(dia.equals(fechaActual.trim())){
                    fechasSolicitada.add(i);
                }   
            }
             ArrayList<Integer> indicesEntre = new ArrayList<Integer>();
            for (int e :fechasSolicitada){
                String dis=dispositivos1.get(e);
                if(this.dispositivosFavoritos.contains(dis.trim())){
                   indicesEntre.add(e);
                }  
            }
            ArrayList<Boolean> datos = send.getDatosBoolean();
            ArrayList<Boolean> valorFinal= new ArrayList<Boolean>();
            for (int o :indicesEntre){
                boolean f =datos.get(o);
                 valorFinal.add(f);
                 
            }
             PrintWriter writer = new PrintWriter("Imprecion.txt", "UTF-8");
            writer.println("Para la fecha del:"+fechaActual);
            if(valorFinal.size()>0){
            for (boolean w :valorFinal){
                if(w==true){
                    writer.println(mensaje1);
                }else{
                     writer.println(mensaje2);
                }
            }}else{
            }writer.close();
            //imprim archivo
           
    
    }
    
        
    
}
